﻿Starter Pack v1 - placeholders
Contains: LoI template, protective order template placeholder, PIO slide placeholder.
Replace each placeholder with real documents before release.
